#!/bin/bash

# 🚀 ElevenBase Migration Script
# Automatizza la migrazione del codice nella repository elvenbase/elevenbase.app

set -e  # Exit on any error

echo "🚀 ElevenBase Migration Script"
echo "============================="
echo ""

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funzione per print colorato
print_step() {
    echo -e "${BLUE}📋 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check prerequisiti
print_step "Controllo prerequisiti..."

if ! command -v git &> /dev/null; then
    print_error "Git non trovato. Installa Git e riprova."
    exit 1
fi

if ! command -v node &> /dev/null; then
    print_error "Node.js non trovato. Installa Node.js 18+ e riprova."
    exit 1
fi

if ! command -v npm &> /dev/null; then
    print_error "npm non trovato. Installa npm e riprova."
    exit 1
fi

print_success "Prerequisiti verificati"

# Variabili
REPO_URL="https://github.com/elvenbase/elevenbase.app.git"
REPO_DIR="elevenbase.app"
MIGRATION_SOURCE="/tmp/elevenbase-migration"

# Step 1: Clone repository
print_step "Clonazione repository elvenbase/elevenbase.app..."

if [ -d "$REPO_DIR" ]; then
    print_warning "Directory $REPO_DIR già esistente. La rimuovo..."
    rm -rf "$REPO_DIR"
fi

git clone "$REPO_URL" "$REPO_DIR"
cd "$REPO_DIR"

print_success "Repository clonata"

# Step 2: Backup
print_step "Creazione backup..."

BACKUP_BRANCH="backup-$(date +%Y%m%d-%H%M%S)"
git checkout -b "$BACKUP_BRANCH"
git push origin "$BACKUP_BRANCH" || print_warning "Impossibile pushare backup (forse repo vuoto)"

git checkout main
print_success "Backup creato su branch: $BACKUP_BRANCH"

# Step 3: Backup contenuto esistente
print_step "Backup contenuto esistente..."
if [ "$(ls -A .)" ]; then
    mkdir -p backup-old-content
    # Copia tutto tranne .git e backup directories
    find . -maxdepth 1 -not -name '.' -not -name '.git' -not -name 'backup-*' -exec cp -r {} backup-old-content/ \; 2>/dev/null || true
    print_success "Contenuto esistente salvato in backup-old-content/"
else
    print_success "Repository vuota, nessun backup necessario"
fi

# Step 4: Rimozione contenuto esistente
print_step "Rimozione contenuto esistente..."
find . -maxdepth 1 -not -name '.' -not -name '.git' -not -name 'backup-*' -exec rm -rf {} + 2>/dev/null || true
print_success "Contenuto esistente rimosso"

# Step 5: Copia nuovi file
print_step "Copia file ElevenBase..."

if [ ! -d "$MIGRATION_SOURCE" ]; then
    print_error "Directory sorgente $MIGRATION_SOURCE non trovata!"
    print_error "Assicurati di aver eseguito la preparazione dei file."
    exit 1
fi

# Copia tutti i file
cp -r "$MIGRATION_SOURCE"/* .
cp -r "$MIGRATION_SOURCE"/.* . 2>/dev/null || true

# Rimuovi .git duplicato se presente
rm -rf .git.migrated 2>/dev/null || true

print_success "File ElevenBase copiati"

# Step 6: Installazione dipendenze
print_step "Installazione dipendenze..."

rm -rf node_modules package-lock.json 2>/dev/null || true
npm install

print_success "Dipendenze installate"

# Step 7: Test build
print_step "Test build..."

if npm run build; then
    print_success "Build completata con successo"
else
    print_error "Build fallita! Controlla gli errori sopra."
    exit 1
fi

# Step 8: Configurazione Git
print_step "Configurazione Git..."

git add .

# Commit
COMMIT_MSG="feat: migrazione completa da Lovable a ElevenBase

- Rimosso dipendenze Lovable (lovable-tagger)
- Aggiornato branding per ElevenBase  
- Configurato supporto variabili d'ambiente
- Aggiornato README e documentazione
- Mantenute tutte le funzionalità esistenti

Migrazione automatica del $(date)"

git commit -m "$COMMIT_MSG"

print_success "Commit creato"

# Step 9: Push
print_step "Push su GitHub..."

if git push origin main; then
    print_success "Push completato!"
else
    print_warning "Push fallito. Potrai farlo manualmente più tardi."
fi

# Step 10: Cleanup
print_step "Cleanup..."
rm -rf dist/ 2>/dev/null || true
print_success "Cleanup completato"

# Risultato finale
echo ""
echo "🎉 MIGRAZIONE COMPLETATA CON SUCCESSO!"
echo "======================================"
echo ""
echo -e "${GREEN}✅ Repository migrata in: $(pwd)${NC}"
echo -e "${GREEN}✅ Backup creato su branch: $BACKUP_BRANCH${NC}"
echo -e "${GREEN}✅ Build testata e funzionante${NC}"
echo -e "${GREEN}✅ Codice pushato su GitHub${NC}"
echo ""
echo "🚀 PROSSIMI PASSI:"
echo "=================="
echo "1. 🌐 Deploy su Vercel:"
echo "   - Vai su vercel.com"
echo "   - Importa elvenbase/elevenbase.app"
echo "   - Deploy automatico!"
echo ""
echo "2. 🔧 Configurazione Supabase (opzionale):"
echo "   - Copia .env.example in .env"
echo "   - Aggiungi le tue credenziali Supabase"
echo ""
echo "3. 🎨 Personalizzazioni:"
echo "   - Logo in /public/"
echo "   - Branding in src/components/Navigation.tsx"
echo "   - Domini personalizzati su Vercel"
echo ""
echo -e "${BLUE}📖 Guida completa: ./MIGRATION-GUIDE.md${NC}"
echo -e "${BLUE}📚 README: ./README.md${NC}"
echo ""
echo -e "${GREEN}🎊 ElevenBase è pronta per andare live su elevenbase.app!${NC}"