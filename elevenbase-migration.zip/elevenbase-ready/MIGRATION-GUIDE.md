# 🚀 Guida Migrazione per elevenbase.app

Questa guida ti aiuterà a migrare il codice nella tua repository `elvenbase/elevenbase.app`.

## 📋 Preparazione

### 1. Backup della repository esistente
```bash
# Clona la tua repository esistente
git clone https://github.com/elvenbase/elevenbase.app.git
cd elevenbase.app

# Crea un backup branch
git checkout -b backup-$(date +%Y%m%d-%H%M)
git push origin backup-$(date +%Y%m%d-%H%M)
```

### 2. Preparazione per la migrazione
```bash
# Torna al branch main
git checkout main

# Opzionale: salva contenuto esistente
mkdir -p backup-old-content
cp -r * backup-old-content/ 2>/dev/null || true
```

## 📂 Migrazione dei File

### Metodo 1: Sostituzione Completa (Raccomandato)
```bash
# Rimuovi tutto il contenuto esistente (esclusi .git e backup)
find . -maxdepth 1 -not -name '.' -not -name '.git' -not -name 'backup-*' -exec rm -rf {} +

# Copia tutti i file dalla directory preparata
cp -r /tmp/elevenbase-migration/* .
cp -r /tmp/elevenbase-migration/.* . 2>/dev/null || true

# Rimuovi .git duplicato se presente
rm -rf .git.migrated 2>/dev/null || true
```

### Metodo 2: Migrazione Selettiva
Se vuoi mantenere alcuni file esistenti:

```bash
# File essenziali da copiare
cp -r /tmp/elevenbase-migration/src ./
cp -r /tmp/elevenbase-migration/supabase ./
cp -r /tmp/elevenbase-migration/public ./
cp /tmp/elevenbase-migration/package.json ./
cp /tmp/elevenbase-migration/vite.config.ts ./
cp /tmp/elevenbase-migration/tailwind.config.ts ./
cp /tmp/elevenbase-migration/tsconfig*.json ./
cp /tmp/elevenbase-migration/components.json ./
cp /tmp/elevenbase-migration/postcss.config.js ./
cp /tmp/elevenbase-migration/eslint.config.js ./
cp /tmp/elevenbase-migration/.env.example ./
cp /tmp/elevenbase-migration/index.html ./
cp /tmp/elevenbase-migration/README.md ./
```

## 🔧 Setup Post-Migrazione

### 1. Installa dipendenze
```bash
# Rimuovi node_modules esistenti
rm -rf node_modules package-lock.json

# Installa nuove dipendenze
npm install
```

### 2. Configura Supabase (Opzionale)
```bash
# Se vuoi usare il tuo database
cp .env.example .env

# Modifica .env con le tue credenziali Supabase
nano .env
```

### 3. Test dell'applicazione
```bash
# Test build
npm run build

# Test sviluppo
npm run dev
```

### 4. Commit delle modifiche
```bash
# Aggiungi tutti i file
git add .

# Commit
git commit -m "feat: migrazione completa da Lovable a ElevenBase

- Rimosso dipendenze Lovable (lovable-tagger)
- Aggiornato branding per ElevenBase
- Configurato supporto variabili d'ambiente
- Aggiornato README e documentazione
- Mantenute tutte le funzionalità esistenti"

# Push su GitHub
git push origin main
```

## 🌐 Deploy su Vercel

### Setup Automatico
1. Vai su [vercel.com](https://vercel.com)
2. Connetti il tuo account GitHub
3. Importa `elvenbase/elevenbase.app`
4. Vercel rileverà automaticamente Vite
5. Deploy!

### Setup Manuale
```bash
# Installa Vercel CLI
npm i -g vercel

# Deploy
vercel

# Per deploy di produzione
vercel --prod
```

### Configurazione Vercel
- **Framework**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Node.js Version**: 18.x

### Variabili d'Ambiente su Vercel
Se usi il tuo database Supabase:
1. Vai su Project Settings → Environment Variables
2. Aggiungi:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`

## 🌐 Deploy su Netlify

### Drag & Drop
1. Esegui `npm run build`
2. Vai su [netlify.com](https://netlify.com)
3. Drag & drop la cartella `dist/`

### Git Integration
1. Connetti repository su Netlify
2. Configurazioni:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
   - **Node version**: 18

### File di Configurazione Netlify
Crea `netlify.toml`:
```toml
[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

## 🔧 Personalizzazioni Opzionali

### 1. Logo e Branding
- Sostituisci `/public/vite.svg` con il tuo logo
- Aggiorna `/src/components/Navigation.tsx` per il logo nell'app
- Modifica favicon in `/public/`

### 2. Domini Personalizzati
- **Vercel**: Project Settings → Domains
- **Netlify**: Site Settings → Domain management

### 3. Analytics (Opzionale)
Aggiungi in `index.html`:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_TRACKING_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_TRACKING_ID');
</script>
```

## ✅ Checklist Post-Migrazione

- [ ] Build locale funziona (`npm run build`)
- [ ] App funziona in sviluppo (`npm run dev`)
- [ ] Deploy su hosting funziona
- [ ] Database Supabase connesso
- [ ] Autenticazione funziona
- [ ] Tutte le pagine accessibili
- [ ] Design responsive su mobile
- [ ] Logo e branding aggiornati
- [ ] Dominio personalizzato configurato (opzionale)
- [ ] Analytics configurato (opzionale)

## 🆘 Troubleshooting

### Build Errors
```bash
# Pulisci cache
rm -rf node_modules package-lock.json dist
npm install
npm run build
```

### Routing Issues
Assicurati che il tuo hosting supporti SPA:
- **Vercel**: Automatico
- **Netlify**: Aggiungi file `public/_redirects`:
  ```
  /*    /index.html   200
  ```

### Supabase Connection
- Verifica URL e chiavi in `.env`
- Controlla console browser per errori
- Verifica CORS settings su Supabase

## 🎉 Completamento

Una volta completata la migrazione, la tua app ElevenBase sarà:
- ✅ Completamente indipendente da Lovable
- ✅ Hostata sulla tua infrastruttura
- ✅ Personalizzabile al 100%
- ✅ Pronta per nuove funzionalità

**Congratulazioni! 🎊 ElevenBase è ora live su elevenbase.app!**