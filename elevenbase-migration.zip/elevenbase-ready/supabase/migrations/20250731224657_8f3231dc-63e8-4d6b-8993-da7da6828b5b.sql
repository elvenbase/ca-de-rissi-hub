-- Elimina tutte le sessioni di allenamento esistenti e i dati correlati
DELETE FROM training_attendance;
DELETE FROM training_lineups;
DELETE FROM training_sessions;