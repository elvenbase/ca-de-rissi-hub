-- Elimina la sessione di allenamento esistente
DELETE FROM public.training_sessions 
WHERE id = '13ce5947-14aa-41c9-b557-bdf34ab651ab';