-- Clean all test data from the database
DELETE FROM training_attendance;
DELETE FROM trial_evaluations;
DELETE FROM player_statistics;
DELETE FROM matches;
DELETE FROM training_sessions;
DELETE FROM competitions;
DELETE FROM trialists;
DELETE FROM players;