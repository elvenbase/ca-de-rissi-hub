-- Add avatar_url column to trialists table
ALTER TABLE public.trialists ADD COLUMN avatar_url TEXT;