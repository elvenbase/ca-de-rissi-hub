# 🏆 ElevenBase - Sistema di Gestione Squadra

Sistema completo e moderno per la gestione di squadre sportive, sviluppato con le migliori tecnologie web.

## ⚡ Demo Live
🔗 **[elevenbase.app](https://elevenbase.app)**

## 🚀 Caratteristiche Principali

### 🏠 Dashboard Intelligente
- 📊 Panoramica generale con statistiche real-time
- 👥 Conteggio giocatori attivi/inattivi
- 📅 Prossimi allenamenti e competizioni
- 📈 Metriche di performance

### 👨‍⚽ Gestione Squad Completa
- ✅ Anagrafica giocatori dettagliata
- 🏷️ Stati: attivo, inattivo, infortunato, sospeso
- 🔢 Gestione numeri di maglia
- 📍 Posizioni e ruoli tattici
- 📊 Statistiche individuali stagionali

### 🏃‍♂️ Sistema Prove Avanzato
- 📝 Gestione trialists con valutazioni complete
- 🎯 Punteggi: tecnico, fisico, tattico, atteggiamento
- 📋 Kanban board per follow-up prove
- 🔄 Stati: in_prova → promosso → archiviato

### 🏋️‍♂️ Gestione Allenamenti
- 📅 Programmazione sessioni dettagliate
- ✅ Sistema presenze automatizzato
- 🔗 Condivisione pubblica con QR code
- 📱 Registrazione mobile-friendly
- ⏰ Gestione orari e location

### 🏆 Competizioni & Partite
- 🏅 Gestione campionati e tornei
- 📅 Calendario partite completo
- ⚽ Risultati e punteggi
- 🏠 Gestione casa/trasferta
- 📊 Statistiche competitive

### ⚽ Formazioni Tattiche
- 🎯 Builder formazioni interattivo
- 📋 Lineup manager avanzato
- 👁️ Visualizzazione schieramenti
- 💾 Salvataggio formazioni preferite

### 🔐 Sistema Ruoli
- 👑 **Superadmin**: Controllo totale
- 🛡️ **Admin**: Gestione squadra e competizioni
- 🎓 **Coach**: Allenamenti e valutazioni

## 🛠️ Stack Tecnologico

### Frontend
- ⚛️ **React 18** - UI Library moderna
- 🔷 **TypeScript** - Type safety
- ⚡ **Vite** - Build tool velocissimo
- 🎨 **Tailwind CSS** - Utility-first CSS
- 🧩 **shadcn/ui** - Componenti di alta qualità

### Backend & Database
- 🗄️ **Supabase** - Backend-as-a-Service
- 🐘 **PostgreSQL** - Database relazionale
- 🔐 **Row Level Security** - Sicurezza avanzata
- 🔄 **Real-time subscriptions** - Aggiornamenti live

### State Management & Tools
- 🔄 **React Query** - Server state management
- 🛣️ **React Router** - Navigazione SPA
- 📋 **React Hook Form** - Form management
- ✅ **Zod** - Schema validation
- 🎨 **Lucide Icons** - Iconografia moderna

## 🚀 Quick Start

### Prerequisiti
- Node.js 18+ 
- npm/yarn/pnpm
- Account Supabase (opzionale per testing)

### Installazione
```bash
# Clona il repository
git clone https://github.com/elvenbase/elevenbase.app.git
cd elevenbase.app

# Installa dipendenze
npm install

# Avvia in sviluppo
npm run dev
```

L'app sarà disponibile su `http://localhost:8080`

### Configurazione Supabase

#### Opzione 1: Test con database esistente
L'app è preconfigurata con un database di test funzionante.

#### Opzione 2: Tuo database personalizzato
1. Crea progetto su [supabase.com](https://supabase.com)
2. Crea file `.env`:
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```
3. Esegui migrazioni da `supabase/migrations/`

## 📁 Struttura Progetto

```
src/
├── components/          # Componenti UI riutilizzabili
├── pages/              # Pagine dell'applicazione
├── contexts/           # Context providers (Auth, Theme)
├── hooks/              # Custom hooks
├── integrations/       # Configurazioni esterne (Supabase)
├── lib/               # Utilities e helpers
└── data/              # Dati statici e configurazioni

supabase/
├── migrations/        # Schema database e migrazioni
└── functions/         # Edge functions (future)
```

## 🌐 Deploy & Hosting

### Vercel (Raccomandato)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/elvenbase/elevenbase.app)

### Netlify
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/elvenbase/elevenbase.app)

### Build manuale
```bash
npm run build
# Output in cartella `dist/`
```

## 📱 Funzionalità Mobile

- 📱 **Progressive Web App** ready
- 🔄 **Responsive design** per tutti i dispositivi
- 📶 **Offline capability** (in arrivo)
- 🔔 **Push notifications** (in arrivo)

## 🔒 Sicurezza & Privacy

- 🛡️ **Row Level Security** su tutti i dati
- 🔐 **Autenticazione JWT** con Supabase
- 🚫 **Nessun tracking** di terze parti
- 📊 **GDPR compliant**

## 🤝 Contribuire

1. 🍴 Fork del progetto
2. 🌿 Crea feature branch (`git checkout -b feature/AmazingFeature`)
3. 💾 Commit modifiche (`git commit -m 'Add some AmazingFeature'`)
4. 📤 Push del branch (`git push origin feature/AmazingFeature`)
5. 🔃 Apri Pull Request

## 📄 Licenza

Distribuito sotto licenza MIT. Vedi `LICENSE` per dettagli.

## 🙋‍♂️ Supporto

- 📧 Email: [support@elevenbase.app](mailto:support@elevenbase.app)
- 🐛 Issues: [GitHub Issues](https://github.com/elvenbase/elevenbase.app/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/elvenbase/elevenbase.app/discussions)

---

**Sviluppato con ❤️ per le squadre sportive moderne**

🔗 [elevenbase.app](https://elevenbase.app) | 🐙 [GitHub](https://github.com/elvenbase) | 🐦 [Twitter](https://twitter.com/elevenbase)
